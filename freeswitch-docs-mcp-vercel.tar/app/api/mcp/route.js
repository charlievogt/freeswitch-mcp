import { createMcpHandler } from "mcp-handler/nextjs";
import { createServer } from "../../../lib/server.mjs";

const handler = createMcpHandler(createServer);

export { handler as GET, handler as POST, handler as DELETE };
